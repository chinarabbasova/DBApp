package com.company.resume;

//public class UserRequestUtil {
//    public static void chechRequest(HttpServletRequest request, HttpServletResponse response) throws IllegalArgumentException {
//
//    }
//}

